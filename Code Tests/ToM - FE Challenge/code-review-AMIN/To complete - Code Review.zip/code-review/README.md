# Instructions

Please complete a code review on the JS, HTML, and CSS included with this README file.  

The provided code does not work.  Getting the code to work is only part of the exercise.  There are many additional issues with the code; please address those issues with an eye towards future maintainability and good coding standards.  Assume the code was written by a junior developer who may need guidance.

What changes would you request from the junior developer?  Why would you request the proposed changes?

Thank you.